﻿using Microsoft.EntityFrameworkCore;
using PayrollEmployeeAPI.Contexts;
using PayrollEmployeeAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PayrollEmployeeAPI.Repositories
{
    class EmployeeRepository : IEmployeeRepo
    {

        private readonly EmployeeContext _dbContext;

        public EmployeeRepository(EmployeeContext dbContext)
        {
            this._dbContext = dbContext;

        }


        public void AddEmployee(Employee employee)
        {
            this._dbContext.Add(employee);
            Save();
        }

        public void DeleteEmployeeById(long employeeId)
        {
            var employee = _dbContext.Employees.Find(employeeId);
            _dbContext.Employees.Remove(employee);
            Save();
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            var employees = _dbContext.Employees.Include(employee=> employee.AddressList).ToList();

            return employees;
        }

        public Employee GetEmployeeById(long employeeId)
        {
            var employee = _dbContext.Employees.Include(c => c.AddressList)
               .FirstOrDefault(x => x.EmployeeId == employeeId);

            return employee;

        }

        public void UpdateEmployeeById(Employee employee)
        {
            _dbContext.Entry(employee).State = EntityState.Modified;
            Save();
        }
        public void Save()
        {
            _dbContext.SaveChanges();
        }
    }
}
